<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\support\Facades\DB;
use App\Models\Member;


class EmployeeController extends Controller
{
    function index()
        {
            return Member::find(1)->getDevice;

        }
}



