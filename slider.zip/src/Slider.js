import React from 'react'
import './style.css'
import './script.js'

export default function Slider() {
  return (
     <div>
      <div id="myNav" className="overlay">
        <a href="javascript:void(0)" className="closebtn" onClick={closeNav()}>
          &times;
        </a>
        <div className="overlay-content">
          <a href="#">About</a>
          <a href="#">Services</a>
          <a href="#">Clients</a>
          <a href="#">Contact</a>
        </div>
      </div>

      <h2>testing the nav</h2>
      <span className="spanText" onClick={openNav()}>
        &#9776; open
      </span>
    </div>
  );
  function openNav() {
    alert('open');
    document.getElementById('myNav').style.width = '100%';
  }

  function closeNav() {
    alert('close');
    document.getElementById('myNav').style.width = '0%';
  }
  
}
