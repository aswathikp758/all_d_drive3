import logo from './logo.svg';
import './App.css';
import Slider from './Slider';

function App() {
  return (
    <div className="App">
  <Slider/> 
    </div>
  );
}

export default App;
