<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
class ProductController extends Controller
{
     public function addProduct(){
        return view('add_product');
    }
    //Store image
    public function storeProduct(Request $request){
      $data= new Product();

        if($request->file('image')){
            $file= $request->file('image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('public/Image'), $filename);
            $data['image']= $filename;
            $data->name=$request->product;
            $data->price=$request->price;
            $data->quantity=$request->quantity;
            $data->description=$request->desc;
        }
        $data->save();
        return redirect()->route('products.list');
    }





     public function productList()
    {
        $products = Product::all();

        return view('products', compact('products'));
    }

    public function add_cart()
    {
        return view('add_cart');
    }
   public function showData($id)
    {
        $prod=Product::find($id);
        return view('cart',['prods'=>$prod]);
    }
}
